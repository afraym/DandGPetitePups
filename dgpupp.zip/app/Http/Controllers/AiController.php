<?php

namespace App\Http\Controllers;

use App\Models\Ai;
use Illuminate\Http\Request;
use Gemini;

class AiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request)
    {

        $details = $request->only([
            'name','price', 'breed_name','Photo_Date', 'Gender', 'Size', 
            'Birth_Date', 'Color', 'Available_From', 'Available_To',
            'Champion_Bloodlines', 'Champion_Sired',
            'Vaccinations_And_Dewormings', 'Health_Certificate', 'Health_Record',
            'Health_Warranty','location',
          ]);

        $yourApiKey = 'AIzaSyAj6aOdluCbK0IoSU0pd9nvDUC7r3TSuT4';
        $client = Gemini::client($yourApiKey);

        $shortDescription = $client->geminiPro()->generateContent("Generate a short description to sell a puppy
        with this details ".json_encode($details))->text();

        $description = $client->geminiPro()->generateContent("Generate an description to sell a puppy
        with this details ".json_encode($details))->text();

        return response()->json(['shortDesription' =>  $shortDescription, 'longDescription' => $description],200); 
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Ai $ai)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Ai $ai)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Ai $ai)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Ai $ai)
    {
        //
    }
}
