
<?php $__env->startSection('content'); ?>
<?php $todaysdate = date('m/d/Y');
// dd($breed)
 ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"> Edit Breed</h4>
                </div>
                <div class="card-body">
                    <div class="alert alert-success" style="display: none;" id="success">
                        <strong>Success!</strong> Breed Updated Successfully <a href="" id="viewLink"
                            target="_blank">View</a>
                    </div>
                    <form name="newBreed" method="POST" action="/admin/breed/update/<?php echo e($breed->id); ?>" id="newBreed" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PATCH')); ?>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Name</label>
                            <input type="text" class="form-control" name="name" id="name" placeholder="Breed Name"
                                required="required" value="<?php echo e($breed->name); ?>">
                        </div>

                        <div class="form-group">
                            <label for="exampleInputEmail1">Image:</label>
                            <br>
                            <a href="/breeds/<?php echo e($breed->image); ?>" target="_blank" rel="noopener noreferrer">
                                <img src="/breeds/<?php echo e($breed->image); ?>" alt="<?php echo e($breed->name); ?>" class="img-thumbnail" style="width: 35%; height:20%">
                              </a>
                        </div>
                        <label for="exampleInputEmail1">Replace Image:</label>
                        <div class="form-group dropzone card" id="my-dropzone">
                            
                            <div class="dz-message" data-dz-message style="font-size: 30px;">
                                <span><?php echo e(__('Drop breed image here to upload')); ?> <i
                                        class="now-ui-icons media-1_camera-compact"></i></i></span></div>

                        </div>

                        <div class="form-group">
                            <label for="breeddesc">Description :</label>
                            <div name="description" id="breeddesc" name="breeddesc" class="htmledit"><?php echo $breed->description; ?></div>
                            <input type="hidden" id="breedDescHtml" name="breeddeschtml" class="htmlvalue" value="<?php echo $breed->description; ?>">
                        </div>

                        <div class="form-group">
                            <label for="metaTitle">Meta Title:</label>
                            <input type="text" class="form-control" name="metaTitle"
                                value="<?php echo e($breed->metaTitle); ?>" data-datepicker-color="primary">
                        </div>
                        <div class="form-group">
                            <label for="metaDescription">Meta Description:</label>
                            <input type="text" class="form-control" name="metaDescription"
                                value="<?php echo e($breed->metaDescription); ?>" data-datepicker-color="primary">
                        </div>
                        <div class="form-group">
                            <label for="metaKeywords">Meta Keywords:</label>
                            <input type="text" class="form-control" name="metaKeywords"
                                value="<?php echo e($breed->metaKeywords); ?>" data-datepicker-color="primary">
                                <small id="metaKeywords" class="form-text text-muted">Separate each word with a comma ,</small>
                        </div>
                        <button type="submit" class="btn btn-primary" id="submitbreed">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dgpups\resources\views/back/breed/edit.blade.php ENDPATH**/ ?>