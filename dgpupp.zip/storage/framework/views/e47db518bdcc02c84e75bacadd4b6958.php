    <?php $__sessionArgs = ['success'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-success">
      <button type="button" aria-hidden="true" class="close">
          <i class="now-ui-icons ui-1_simple-remove"></i>
      </button>
      <span><b> Success! - </b> <?php echo session('success'); ?></span>
  </div>
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
    <?php $__sessionArgs = ['error'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
    <div class="alert alert-danger">
      <button type="button" aria-hidden="true" class="close">
          <i class="now-ui-icons ui-1_simple-remove"></i>
      </button>
      <span><b> Error! - </b> <?php echo e(session('error')); ?></span>
  </div>
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger">
      <button type="button" aria-hidden="true" class="close">
          <i class="now-ui-icons ui-1_simple-remove"></i>
      </button>
      <span><b> Error ! - </b> <?php echo e($message); ?></span>
    </div>
<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    <div class="alert alert-success" style="display: none;" id="success">
        
      </div><?php /**PATH C:\laragon\www\dgpups\resources\views/back/inc/alerts.blade.php ENDPATH**/ ?>