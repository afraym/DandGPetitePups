
<?php $__env->startSection('content'); ?>

<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Puppies Table</h4>
        </div>
        <div class="card-body">
          <?php echo $__env->make('back.inc.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="table-responsive">
            <table class="table">
              <thead class="text-primary">
                <th>
                  Name
                </th>
                <th>
                  Image
                </th>
                <th>
                  Edit
                </th>
                <th class="text-right">
                  Delete
                </th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $puppies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $puppy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <a href="/puppy/<?php echo e($puppy->id); ?>/<?php echo e($puppy->name); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($puppy->name); ?></a>
                  </td>
                  <td>
                    <?php if(!isset($puppy->puppy_images[0])): ?>
                    <a href="/puppy/<?php echo e($puppy->id); ?>/<?php echo e($puppy->name); ?>" target="_blank" rel="noopener noreferrer">
                      <img src="/assets/images/bg/404image.jpg" alt="<?php echo e($puppy->name); ?>" class="img-thumbnail" style="width: 20%; height:20%">
                    </a>
                    <?php else: ?>
                    <a href="/puppy/<?php echo e($puppy->id); ?>/<?php echo e($puppy->name); ?>" target="_blank" rel="noopener noreferrer">
                      <img src="/<?php echo e($puppy->puppy_images['0']->link.$puppy->puppy_images[0]->name); ?>" alt="<?php echo e($puppy->name); ?>" onerror="this.onerror=null; this.src='/assets/images/bg/404image.jpg'"  class="img-thumbnail" style="width: 20%; height:20%">
                    </a>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?php echo e(Route('admin.puppy.edit', $puppy->id)); ?> "><button class="btn btn-info">Edit</button></a>
                  </td>
                  <td class="text-right">
                    <button class="btn btn-danger deleteitem" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($puppy->id); ?>" >Delete</button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php echo e($puppies->links()); ?>

    </div>
  </div>
</div>


<!-- The Delete Modal -->
<div class="modal fade" id="deleteModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Are you sure?</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        This will delete this Puppy from database and all it's photos
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <form action="<?php echo e(Route('admin.puppy.delete')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" value="" id='deleteitem' name="id">
        <button type="submit" class="btn btn-danger">Yes, Delete</button>
      </form>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dgpups\resources\views/back/puppy/index.blade.php ENDPATH**/ ?>