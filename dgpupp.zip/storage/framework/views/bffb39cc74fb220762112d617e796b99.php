
<?php $__env->startSection('content'); ?>
<div class="panel-header panel-header-sm">
</div>
<div class="content">
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Breeds Table</h4>
        </div>
        <div class="card-body">
          <?php echo $__env->make('back.inc.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          <div class="table-responsive">
            <table class="table">
              <thead class=" text-primary">
                <th>
                  Name
                </th>
                <th>
                  Image
                </th>
                <th>
                  Edit
                </th>
                <th class="text-right">
                  Delete
                </th>
              </thead>
              <tbody>
                <?php $__currentLoopData = $breeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td>
                    <?php echo e($breed->name); ?>

                  </td>
                  <td>
                    <img src="/breeds/<?php echo e($breed->image); ?>" alt="<?php echo e($breed->metaTitle); ?>" class="img-thumbnail" style="width: 20%; height:20%">
                  </td>
                  <td>
                    <a href="<?php echo e(Route('admin.breed.edit', $breed->id)); ?> "><button class="btn btn-info">Edit</button></a>
                  </td>
                  <td class="text-right">
                    <button class="btn btn-danger deleteitem" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo e($breed->id); ?>" >Delete</button>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
      <?php echo e($breeds->links()); ?>

    </div>
  </div>
</div>

<!-- The Delete Modal -->
<div class="modal fade" id="deleteModal">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Are you sure?</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        This will delete this Breed from database and it's photo
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <form action="<?php echo e(Route('admin.breed.delete')); ?>" method="post">
          <?php echo csrf_field(); ?>
          <input type="hidden" value="" id='deleteitem' name="id">
        <button type="submit" class="btn btn-danger" >Yes, Delete</button>
      </form>
      </div>

    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.back', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\dgpups\resources\views/back/breed/index.blade.php ENDPATH**/ ?>