
@include('back.inc.header')
@yield('content')

@include('back.inc.footer')