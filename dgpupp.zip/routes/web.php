<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;

Route::get('/', function () {
    return view('front.index');
});

// admin routes
Route::prefix('admin')->group(function () {
// puppies routes    
Route::get('/puppy/new', [App\Http\Controllers\PuppyController::class, 'create'])->name('admin.puppy.create');
Route::get('/puppy/all', [App\Http\Controllers\PuppyController::class, 'list'])->name('admin.puppy.list');
Route::get('/puppy/edit/{id}', [App\Http\Controllers\PuppyController::class, 'edit'])->name('admin.puppy.edit');
Route::patch('/puppy/update/{id}', [App\Http\Controllers\PuppyController::class, 'update'])->name('admin.puppy.update');
Route::post('/puppy/delete/', [App\Http\Controllers\PuppyController::class, 'destroy'])->name('admin.puppy.delete');
Route::post('/ai/new', [App\Http\Controllers\AiController::class, 'create'])->name('admin.ai.create');


Route::get('/breed/new', [App\Http\Controllers\BreedController::class, 'create'])->name('admin.breed.create');
Route::get('/breed/edit/{id}', [App\Http\Controllers\BreedController::class, 'edit'])->name('admin.breed.edit');


Route::post('/puppy/add', [App\Http\Controllers\PuppyController::class, 'store'])->name('puppySave');

Route::get('/breed/all', [App\Http\Controllers\BreedController::class, 'list'])->name('admin.breed.list');
Route::post('/breed/delete/', [App\Http\Controllers\BreedController::class, 'destroy'])->name('admin.breed.delete');
});

// front routes
Route::get('/puppy/{id}/{name}', [App\Http\Controllers\PuppyController::class, 'show']);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');



// Route::get('/dashboard', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
